﻿namespace Adapter
{
    /// <summary>
    /// The 'Target' class
    /// </summary>
    internal interface ICompound
    {
        void Display();
    }
}
