﻿namespace FlyweightGame.UI
{
    internal class AssetPaths
    {
        internal const string ReaperImage = "../../Assets/reaper.png";
    }
}
