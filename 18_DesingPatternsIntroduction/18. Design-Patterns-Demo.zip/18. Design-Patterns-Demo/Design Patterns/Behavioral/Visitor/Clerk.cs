﻿namespace Visitor
{
    internal class Clerk : Employee
    {
        public Clerk()
            : base("Hank", 25000.0, 14)
        {
        }
    }
}
