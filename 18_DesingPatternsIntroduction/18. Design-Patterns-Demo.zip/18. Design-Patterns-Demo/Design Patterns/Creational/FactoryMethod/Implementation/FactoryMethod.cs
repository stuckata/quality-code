﻿namespace FactoryMethod
{
    public abstract class FactoryMethod
    {
        public abstract Product CreateProduct();
    }
}
