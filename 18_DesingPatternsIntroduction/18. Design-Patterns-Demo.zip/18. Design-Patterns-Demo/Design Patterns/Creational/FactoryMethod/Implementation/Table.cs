﻿namespace FactoryMethod
{
    public class Table : Product
    {
        public Table(string description) : base(description)
        {
        }
    }
}
