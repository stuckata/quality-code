﻿namespace FactoryMethod.GsmConglomerate
{
    public abstract class Manufacturer
    {
        public abstract Gsm ManufactureGsm();
    }
}
