﻿namespace FactoryMethod.Factory_method_example___GSM_Conglomerate
{
    public interface IStartable
    {
        void Start();
    }
}
