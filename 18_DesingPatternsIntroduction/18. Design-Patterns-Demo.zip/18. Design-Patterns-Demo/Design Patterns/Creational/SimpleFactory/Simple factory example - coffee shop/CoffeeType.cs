﻿namespace SimpleFactory.CoffeeShop
{
    public enum CoffeeType
    {
        Regular,
        Double,
        Cappuccino,
        Macchiato
    }
}