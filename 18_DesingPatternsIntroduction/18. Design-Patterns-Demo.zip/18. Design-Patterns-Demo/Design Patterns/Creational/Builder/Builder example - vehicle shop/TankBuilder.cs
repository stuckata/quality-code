﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Builder.Builder_example___vehicle_shop
{
    public class TankBuilder : VehicleBuilder
    {
        public override void BuildFrame()
        {
            throw new NotImplementedException();
        }

        public override void BuildEngine()
        {
            throw new NotImplementedException();
        }

        public override void BuildWheels()
        {
            throw new NotImplementedException();
        }

        public override void BuildDoors()
        {
            throw new NotImplementedException();
        }
    }
}
