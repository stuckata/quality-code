Use the improved code from "JavaZmiq" project from the "Naming Identifiers" homework.
