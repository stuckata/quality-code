﻿namespace Cars.Tests.Mocks
{
    using Cars.Contracts;

    public interface ICarsRepositoryMock
    {
        ICarsRepository CarsData { get; }
    }
}
